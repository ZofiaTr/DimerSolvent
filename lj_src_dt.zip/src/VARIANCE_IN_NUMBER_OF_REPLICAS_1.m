NumberOfReplicas=5001;
Variance1=1.20854;
