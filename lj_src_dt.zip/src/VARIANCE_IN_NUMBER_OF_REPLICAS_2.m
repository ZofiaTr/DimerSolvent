NumberOfReplicas2=667;
Variance2=0;
