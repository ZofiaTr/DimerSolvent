#include"particle.h"


int Particle::howManyRestrained=0;
int Particle::howManyActive=0;