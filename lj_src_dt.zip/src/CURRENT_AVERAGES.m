% current time step, temperature, pressure, position (dimer distance), potential V, percentage restr particles, observable 1 (solvent solvent pot), observable 2 (dimer potential), observable 3 (dimer solvent pot), config temperature,number of interactions
A=[
1e+06	0.809393	0	0	0.425083	0	0.425083	0	0.809393	1.18812e-05	4.95049e-06	6.80692e-06	0	
];
