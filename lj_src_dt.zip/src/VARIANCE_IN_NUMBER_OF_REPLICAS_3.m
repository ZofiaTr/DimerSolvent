NumberOfReplicas3=2001;
Variance3=0.0398644;
